def main():
    number = int(input('Enter the number (only positive integers allowed\n'))
    print(f'{number} squares is {number**2}')


if __name__ == '__main__':
    main()