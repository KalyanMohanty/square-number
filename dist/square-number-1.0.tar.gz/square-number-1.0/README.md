# Square Numert takes an integer as an input and prints it square.

## Installation
```pip install square-number```

## How to use it?
Open terminal and type square and then input the integer

## License

© 2022 Kalyan Mohanty

This repository is licensed under the MIT license. See LICENSE for details.